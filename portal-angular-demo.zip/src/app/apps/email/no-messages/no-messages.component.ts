import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-no-messages',
  templateUrl: './no-messages.component.html',
  styleUrls: ['./no-messages.component.scss']
})
export class NoMessagesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
