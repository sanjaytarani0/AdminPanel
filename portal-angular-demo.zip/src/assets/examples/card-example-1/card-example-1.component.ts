import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'card-example-1',
  templateUrl: './card-example-1.component.html',
  styleUrls: ['./card-example-1.component.scss']
})
export class CardExample1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
