import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cart-example-1',
  templateUrl: './cart-example-1.component.html',
  styleUrls: ['./cart-example-1.component.scss']
})
export class CartExample1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
