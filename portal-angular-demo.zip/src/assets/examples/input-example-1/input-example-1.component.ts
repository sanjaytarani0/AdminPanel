import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'example-input-1',
  templateUrl: './input-example-1.component.html',
  styleUrls: ['./input-example-1.component.scss']
})
export class InputExample1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
