import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'list-example-1',
  templateUrl: './list-example-1.component.html',
  styleUrls: ['./list-example-1.component.scss']
})
export class ListExample1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
