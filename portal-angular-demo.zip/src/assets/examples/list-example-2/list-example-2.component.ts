import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'list-example-2',
  templateUrl: './list-example-2.component.html',
  styleUrls: ['./list-example-2.component.scss']
})
export class ListExample2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
