import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'tabs-example-1',
  templateUrl: './tabs-example-1.component.html',
  styleUrls: ['./tabs-example-1.component.scss']
})
export class TabsExample1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
