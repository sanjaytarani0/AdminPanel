import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'toolbar-example-1',
  templateUrl: './toolbar-example-1.component.html',
  styleUrls: ['./toolbar-example-1.component.scss']
})
export class ToolbarExample1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
