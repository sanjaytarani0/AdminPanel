import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'toolbar-example-2',
  templateUrl: './toolbar-example-2.component.html',
  styleUrls: ['./toolbar-example-2.component.scss']
})
export class ToolbarExample2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
