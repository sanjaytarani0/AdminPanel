import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'typography-example',
  templateUrl: './typography-example.component.html',
  styleUrls: ['./typography-example.component.scss']
})
export class TypographyExampleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
