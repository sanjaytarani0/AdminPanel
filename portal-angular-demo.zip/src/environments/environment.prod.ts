export const environment = {
  production: true,
  gdaxURL: 'wss://ws-feed.gdax.com'
};
